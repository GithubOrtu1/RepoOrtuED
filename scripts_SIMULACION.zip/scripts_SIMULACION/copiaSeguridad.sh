#!/bin/bash

# Ruta de las carpetas a respaldar
carpeta_origen="/home/ortu-simu/practica_si"

# Ruta de destino para la copia de seguridad
ruta_destino="/home/ortu-simu/practica_si/backup-simu"

# Nombre del archivo de respaldo
nombre_archivo="backup_simu_$(date +%Y-%m-%d_%H-%M-%S).tar.gz"

# Crear directorio de destino si no existe
mkdir -p "$ruta_destino"

# Crear la copia de seguridad comprimida en un archivo tar.gz
tar -czvf "$ruta_destino/$nombre_archivo" "$carpeta_origen"

echo "La copia de seguridad se ha creado correctamente en: $ruta_destino/$nombre_archivo."

