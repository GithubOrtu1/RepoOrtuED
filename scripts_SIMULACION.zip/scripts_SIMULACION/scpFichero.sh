#!bin/bash

sshpass -p ortu1234  scp /home/ortu/practica_si/backup-simu/kk.tar.gz ortu@192.168.202.128:/home/ortu/practica_si/backup

