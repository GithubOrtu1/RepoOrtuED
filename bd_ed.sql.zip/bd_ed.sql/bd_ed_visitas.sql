CREATE DATABASE  IF NOT EXISTS `bd_ed` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bd_ed`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_ed
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `visitas`
--

DROP TABLE IF EXISTS `visitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitas` (
  `idvisitas` int NOT NULL AUTO_INCREMENT,
  `dni_paciente` varchar(45) NOT NULL,
  `fecha_visita` datetime NOT NULL,
  `peso` float NOT NULL,
  `altura` float NOT NULL,
  `imc` int NOT NULL,
  `cod_profesional` int NOT NULL,
  PRIMARY KEY (`idvisitas`),
  KEY `fk_cod_profesional_idx` (`cod_profesional`),
  KEY `fk_dni_paciente_idx` (`dni_paciente`),
  CONSTRAINT `fk_cod_profesional` FOREIGN KEY (`cod_profesional`) REFERENCES `profesionales_medicos` (`cod_medico`),
  CONSTRAINT `FK_dni` FOREIGN KEY (`dni_paciente`) REFERENCES `pacientes` (`dni`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitas`
--

LOCK TABLES `visitas` WRITE;
/*!40000 ALTER TABLE `visitas` DISABLE KEYS */;
INSERT INTO `visitas` VALUES (1,'45568773e','1970-01-01 00:00:00',166,1.66,1,100),(2,'45568779E','2023-05-16 21:02:28',100,1.79,1,102),(3,'45568771e','2023-05-16 21:04:13',77,1.77,0,104),(4,'83192411P','2023-05-16 21:26:01',1.88,88,-1,101),(5,'45568779E','2023-05-17 21:26:37',100,2.1,0,102),(6,'5555','2023-05-16 23:42:39',78,1.82,0,103),(7,'45568773e','2023-05-16 23:56:43',1.89,120,-1,104),(8,'30129935G','2023-05-17 14:43:00',1.89,100,-1,104),(9,'72912422F','2023-05-17 17:00:46',2.13,120,-1,101),(10,'82422940W','2023-05-18 18:32:07',1.85,80,-1,104);
/*!40000 ALTER TABLE `visitas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-20 11:13:08
