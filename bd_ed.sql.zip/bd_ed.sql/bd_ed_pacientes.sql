CREATE DATABASE  IF NOT EXISTS `bd_ed` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bd_ed`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_ed
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pacientes`
--

DROP TABLE IF EXISTS `pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacientes` (
  `idpacientes` int NOT NULL AUTO_INCREMENT,
  `dni` varchar(45) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `edad` int NOT NULL,
  `calle` varchar(45) NOT NULL,
  `localidad` varchar(45) NOT NULL,
  `cp` varchar(45) NOT NULL,
  PRIMARY KEY (`idpacientes`),
  KEY `index_dni` (`dni`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacientes`
--

LOCK TABLES `pacientes` WRITE;
/*!40000 ALTER TABLE `pacientes` DISABLE KEYS */;
INSERT INTO `pacientes` VALUES (1,'85564717W','moya',45,'asjsjajsd','orihuela','03300'),(2,'44879856W','perico',34,'asdaasd','molins','03301'),(3,'87446976X','pepe',34,'xxx','bigastro','03302'),(4,'82957790X','pepe',55,'yyy','bigsatro','03302'),(5,'47294439E','antonio',78,'ooooo','murcia','03304'),(6,'27815591N','maria',34,'pppp','madrid','28080'),(7,'12208436J','paco',34,'uwnwjwuw','madrid','28080'),(8,'19082624F','john',67,'hahahs','barna','08080'),(9,'47089752N','rambo',45,'ajsasjs','elda','41234'),(10,'32576067V','juanan',47,'jajsjas','madrid','28080'),(11,'24079116W','luisa',50,'uansns','novelda','41234'),(12,'38648136V','peña',45,'hhh','orihuela','03300'),(13,'96862854X','peñica',45,'uuuu','ori','03300'),(14,'56408486C','peñica2',45,'oooo','ori','03300'),(15,'78773054D','peñica4',45,'hshshshs','ori','03300'),(16,'45568772e','yo',45,'obispo rocamora','orihuela','03301'),(17,'45568773e','pepe',66,'ttt','murcia','666'),(18,'45568774e','yo2',45,'yyyyyyyyyyyyyy','orihuelica','03300'),(19,'45568775e','yo5',55,'uuuuuuuuuu','ori','111'),(20,'45678992e','yo6',66,'iii','ori','666'),(21,'45568779E','yo7',36,'r','s','1'),(22,'45568771e','yo10',77,'e','r','1'),(23,'83192411P','juan pablo',43,'y','w','03300'),(24,'83192411Q','juan2',99,'t','t','1'),(25,'66','barry',43,'r','s','1'),(26,'667','barry2',42,'e','f','1'),(27,'3333','barry',46,'e','r','1'),(28,'5555','barry',40,'e','r','1'),(29,'30129935G','1',1,'1','1','1'),(30,'72912422F','javi',12,'r','r','03300'),(31,'82422940W','sergio',45,'x','molins','03300');
/*!40000 ALTER TABLE `pacientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-20 11:13:08
