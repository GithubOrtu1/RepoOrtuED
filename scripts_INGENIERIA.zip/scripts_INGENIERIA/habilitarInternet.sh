#!/bin/bash

# Limpiar todas las reglas y políticas existentes
sudo iptables -F
#sudo iptables -X
#sudo iptables -Z

# Establecer política predeterminada ACCEPT para las cadenas INPUT, FORWARD y OUTPUT
sudo iptables -P INPUT ACCEPT
sudo iptables -P FORWARD ACCEPT
sudo iptables -P OUTPUT ACCEPT


echo "Conexión a Internet habilitada  en su totalidad"

