#!/bin/bash

# Envio mail de prueba
echo "prueba" | mail -s "mail desde bash" johnt.fortu@gmail.com


