#!bin/bash

sshpass -p ortu-simu1234  scp /home/ortu/practica_si/backup/*.tar.gz ortu-simu@192.168.202.130:/home/ortu-simu/practica_si/backup-simu

