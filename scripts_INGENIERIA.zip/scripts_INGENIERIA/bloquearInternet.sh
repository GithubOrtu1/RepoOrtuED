#!/bin/bash

# Limpiar todas las reglas y políticas existentes
sudo iptables -F
#sudo iptables -X
#sudo iptables -Z

# Establecer política predeterminada ACCEPT para las cadenas INPUT, FORWARD y OUTPUT
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP

echo "Conexión a Internet cortada en su totalidad"

