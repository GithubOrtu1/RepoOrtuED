#!/bin/bash

# Limpiar todas las reglas y políticas existentes
sudo iptables -F
#sudo iptables -X
#sudo iptables -Z

# Establecer política predeterminada ACCEPT para las cadenas INPUT, FORWARD y OUTPUT
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP


# Permitir la comunicación con simulacion
sudo iptables -A INPUT -s 192.168.202.130 -p tcp -j ACCEPT
sudo iptables -A OUTPUT -d 192.168.202.130 -p tcp -j ACCEPT

echo "Conexión a Internet cortada - Conexion con SIMULACION habilitadaa"

