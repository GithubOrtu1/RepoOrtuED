#!/bin/bash

# Se inicia nload para monitorizar el trafico
nload  ens33 -t 1000  > trafico.log &

#Se guarda el pid del proceso nload
nload_pid=$!

# Se descarga el archivo con wget en segundo plano
wget -O ficheroDescargado.zip  http://ipv4.download.thinkbroadband.com/50MB.zip 

# Finalizar el proceso de nload una vez que la descarga ha terminado
kill $nload_pid

# Se muestra un mensaje de finalizacion
echo “La descarga ha finalizado y la monitorizacion del trafico tambien...”



